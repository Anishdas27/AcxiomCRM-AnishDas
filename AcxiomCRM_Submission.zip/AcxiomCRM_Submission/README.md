# AcxiomCRM - Basic Submission

This is a partial ASP.NET Core MVC implementation based on the supplied AcxiomCRM assignment.

## Implemented
- ASP.NET Core MVC project structure
- Dashboard shell with customer count
- Customer Create, Read/List, Update and Delete
- Customer search by name/email
- Client/server model validation for required name, email format, phone format and length
- Duplicate customer email check
- Anti-forgery validation on state-changing forms
- Simple responsive UI
- Entity Framework Core InMemory database for easy demonstration

## Not Yet Implemented
Authentication/ASP.NET Core Identity, Admin/Manager/SalesExecutive authorization, Leads, Opportunities, Follow-Ups, Activities, Audit Log, REST API, dashboard charts, reporting and persistent database storage.

## Run
Requires .NET 8 SDK.

    dotnet restore
    dotnet run

Open the localhost URL printed by ASP.NET Core.
