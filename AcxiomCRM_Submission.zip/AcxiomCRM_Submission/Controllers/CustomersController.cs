using AcxiomCRM.Models; using Microsoft.AspNetCore.Mvc;
namespace AcxiomCRM.Controllers;
public class CustomersController : Controller {
 private readonly CrmContext _db; public CustomersController(CrmContext db)=>_db=db;
 public IActionResult Index(string? q){ var x=_db.Customers.AsQueryable(); if(!string.IsNullOrWhiteSpace(q)) x=x.Where(c=>c.CustomerName.Contains(q)||c.Email.Contains(q)); return View(x.ToList()); }
 public IActionResult Create()=>View();
 [HttpPost,ValidateAntiForgeryToken] public IActionResult Create(Customer c){ if(_db.Customers.Any(x=>x.Email==c.Email)){ModelState.AddModelError("Email","Email already exists.");} if(!ModelState.IsValid)return View(c); _db.Customers.Add(c);_db.SaveChanges();return RedirectToAction(nameof(Index)); }
 public IActionResult Edit(int id){var c=_db.Customers.Find(id);return c==null?NotFound():View(c);}
 [HttpPost,ValidateAntiForgeryToken] public IActionResult Edit(Customer c){if(!ModelState.IsValid)return View(c);_db.Customers.Update(c);_db.SaveChanges();return RedirectToAction(nameof(Index));}
 [HttpPost,ValidateAntiForgeryToken] public IActionResult Delete(int id){var c=_db.Customers.Find(id);if(c!=null){_db.Customers.Remove(c);_db.SaveChanges();}return RedirectToAction(nameof(Index));}
}
