using AcxiomCRM.Models; using Microsoft.AspNetCore.Mvc;
namespace AcxiomCRM.Controllers;
public class HomeController : Controller { private readonly CrmContext _db; public HomeController(CrmContext db)=>_db=db; public IActionResult Index()=>View(_db.Customers.Count()); }
