using Microsoft.EntityFrameworkCore;
namespace AcxiomCRM.Models;
public class CrmContext : DbContext { public CrmContext(DbContextOptions<CrmContext> options):base(options){} public DbSet<Customer> Customers => Set<Customer>(); }
